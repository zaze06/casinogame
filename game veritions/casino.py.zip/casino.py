import random
import os
f= open("mony.txt","w+")
f.write("200")
mony=0
mony=100
name=input("vad heter du :")
if name == "noob":
    name=input("vad heter du måste svara :")
    if name == "debug":
        whitchcollor=input("välj en färg röd eller svart eller grön")
    mony=int(input("hur myket vill du ha :"))
elif name == "debug":
    whitchcollor=input("välj en färg röd eller svart eller grön")
elif name == "klara":
    mony=int(input("ett tall"))
play=0
while play == 0:
    insats_true="nej"
    while insats_true == "nej":
        print("du har ",mony,"kr")
        insats=input("hur myket vill du satsa :")
        if insats == "half":
            insats=int(mony/2)
        elif insats == "all":
            insats=int(mony)
        else:
            insats=int(insats)
        if mony >= insats:
            print("insats gorkänd")
            insats_true="ja"
            mony=mony-insats
            vinst=insats+insats
            gronvinst=insats*1

        else:
            print("insats inte gorkänd")
    if name != "debug":
        collor=input("vilken färg ska du satsa  svart, röd eller grön(bara 1 på 5 att få) :")
        whitchcollor=0
        whitchcollor=random.randint(1,5)
        if whitchcollor == 1 or whitchcollor == 3:
            whitchcollor="röd"
        elif whitchcollor == 5:
            whitchcollor="grön"
        else:
            whitchcollor="svart"
    elif name == "debug":
        collor=input("vilken färg svart, röd eller grön(bara 1 på 5 att få) :")
    if whitchcollor == collor:
            print("du vann",whitchcollor)
            if whitchcollor ==  "grön":
                mony=mony+insats+insats+insats
            else:
                mony=mony+vinst
    else:
            print("försut förgen blev :",whitchcollor)